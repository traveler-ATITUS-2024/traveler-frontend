import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  TextInput,
  TouchableWithoutFeedback,
  Keyboard,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import useCadastroNovaViagemController from "../controller/cadastroviagemController";
improt CadastroViagemUseCase from "../controller" 
import { Calendar } from "react-native-calendars";
import AsyncStorage from "@react-native-async-storage/async-storage";

import marcacaomapa from "../../../../assets/marcacaomapa.png";
import calendarioida from "../../../../assets/calendarioida.png";
import calendariovolta from "../../../../assets/calendariovolta.png";
import logo from "../../../../assets/logo.png";
import flechaesquerda from "../../../../assets/flechaesquerda.png";

export default function CadastroNovaViagem() {
  const navigation = useNavigation();
  const { cidade } = useCadastroNovaViagemController();

  const [tituloViagem, setTituloViagem] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [dataIda, setDataIda] = useState(null);
  const [dataVolta, setDataVolta] = useState(null);
  const [isCalendarVisible, setCalendarVisible] = useState(false);
  const [selectedCalendar, setSelectedCalendar] = useState("");
  const [gastoPrevisto, setGastoPrevisto] = useState("R$ 0,00");

  // Função para salvar a data de ida usando AsyncStorage
  const salvaDataIda = async (dataIdaSelecionada) => {
    try {
      if (dataIdaSelecionada) {
        await AsyncStorage.setItem("@dataIda", dataIdaSelecionada.toISOString());
        console.log(`Data de ida ${dataIdaSelecionada.toISOString()} salva com sucesso!`);
        setDataIda(dataIdaSelecionada);
      } else {
        console.log("Nenhuma data de ida selecionada.");
      }
    } catch (error) {
      console.log("Erro ao salvar sua data de ida!", error);
    }
  };

  // Função para salvar a data de volta usando AsyncStorage
  const salvaDataVolta = async (dataVoltaSelecionada) => {
    try {
      if (dataVoltaSelecionada) {
        await AsyncStorage.setItem("@dataVolta", dataVoltaSelecionada.toISOString());
        console.log(`Data de volta ${dataVoltaSelecionada.toISOString()} salva com sucesso!`);
        setDataVolta(dataVoltaSelecionada);
      } else {
        console.log("Nenhuma data de volta selecionada.");
      }
    } catch (error) {
      console.log("Erro ao salvar sua data de volta!", error);
    }
  };

  // Função para manipular a data de ida
  const handleConfirmIda = (selectedDate) => {
    setCalendarVisible(false);
    salvaDataIda(selectedDate); // Salva a data de ida
  };

  // Função para manipular a data de volta
  const handleConfirmVolta = (selectedDate) => {
    setCalendarVisible(false);
    salvaDataVolta(selectedDate); // Salva a data de volta
  };

  // Função para exibir a data no formato correto, sem interferência de fuso horário
  const formatarData = (date) => {
    if (!date) return "Selecionar data";
    return new Date(date.getTime() + date.getTimezoneOffset() * 60000)
      .toLocaleDateString("pt-BR");
  };

  // Exibe ou esconde o calendário ao clicar nas datas
  const toggleCalendar = (type) => {
    if (selectedCalendar === type && isCalendarVisible) {
      setCalendarVisible(false); // Se o calendário já estiver visível, o oculta
    } else {
      setSelectedCalendar(type); // Define o tipo de calendário (ida ou volta)
      setCalendarVisible(true); // Exibe o calendário
    }
  };

  // Fecha o calendário ao clicar fora dele
  const dismissKeyboardAndCalendar = () => {
    Keyboard.dismiss(); // Fecha o teclado
    if (isCalendarVisible) {
      setCalendarVisible(false);
    }
  };

  // Função para formatar o valor como moeda e manter o prefixo "R$"
  const formatCurrency = (value) => {
    let numericValue = value.replace(/\D/g, "");

    if (numericValue.length === 0) {
      numericValue = "0";
    }

    numericValue = (numericValue / 100).toFixed(2).replace(".", ",");

    numericValue = numericValue.replace(/\B(?=(\d{3})+(?!\d))/g, ".");

    return `R$ ${numericValue}`;
  };

  const handleGastoChange = (value) => {
    setGastoPrevisto(formatCurrency(value));
  };

  const handleAdicionar = () => {
    navigation.navigate("cadastroviagem");
    handleSalvarViagem({
      titulo: tituloViagem,
      dataIda,
      dataVolta,
      gastoPrevisto,
    });
  };

  return (
    <TouchableWithoutFeedback onPress={dismissKeyboardAndCalendar}>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Image
              source={flechaesquerda}
              style={[styles.voltarIcone, { tintColor: "#FFFF" }]}
            />
          </TouchableOpacity>
          <Image source={logo} style={styles.logo} />
        </View>

        {!isEditing ? (
          <TouchableOpacity onPress={() => setIsEditing(true)}>
            <Text style={styles.label}>
              {tituloViagem || "Título da viagem:"}
            </Text>
          </TouchableOpacity>
        ) : (
          <TextInput
            style={styles.input}
            value={tituloViagem}
            placeholder="Digite o título da viagem"
            placeholderTextColor="#999"
            onChangeText={setTituloViagem}
            onBlur={() => setIsEditing(false)}
            autoFocus
          />
        )}

        <View style={styles.linha} />

        <View style={styles.datas}>
          <TouchableOpacity
            onPress={() => toggleCalendar("ida")}
            style={styles.dataContainer}
          >
            <Image source={calendarioida} style={styles.icone} />
            <Text style={styles.textoDatas}>
              {dataIda ? formatarData(dataIda) : "Data de ida"}
            </Text>
          </TouchableOpacity>

          {isCalendarVisible && selectedCalendar === "ida" && (
            <Calendar
              style={styles.calendar}
              headerStyle={{
                borderBottomWidth: 0.5,
                borderBottomColor: "#E8E8E8",
                paddingBottom: 10,
                marginBottom: 10,
              }}
              theme={{
                textMonthFontSize: 18,
                monthTextColor: "#E8E8E8",
                todayTextColor: "#F06543",
                selectedDayBackgroundColor: "#F06543",
                selectedDayTextColor: "#E8E8E8",
              }}
              onDayPress={(day) => handleConfirmIda(new Date(day.dateString))}
            />
          )}

          <TouchableOpacity
            onPress={() => toggleCalendar("volta")}
            style={styles.dataContainer}
          >
            <Image source={calendariovolta} style={styles.icone} />
            <Text style={styles.textoDatas}>
              {dataVolta ? formatarData(dataVolta) : "Data de volta"}
            </Text>
          </TouchableOpacity>

          {isCalendarVisible && selectedCalendar === "volta" && (
            <Calendar
              style={styles.calendar}
              headerStyle={{
                borderBottomWidth: 0.5,
                borderBottomColor: "#E8E8E8",
                paddingBottom: 10,
                marginBottom: 10,
              }}
              theme={{
                textMonthFontSize: 18,
                monthTextColor: "#E8E8E8",
                todayTextColor: "#F06543",
                selectedDayBackgroundColor: "#F06543",
                selectedDayTextColor: "#E8E8E8",
              }}
              onDayPress={(day) => handleConfirmVolta(new Date(day.dateString))}
            />
          )}

          <View style={styles.linha} />
        </View>

        <View style={styles.cidadeContainer}>
          <Image source={marcacaomapa} style={styles.icone} />
          <Text style={styles.cidadeTexto}>
            {cidade || "Selecionar cidade"}
          </Text>
        </View>

        <View style={styles.gastoContainer}>
          <Text style={styles.gastoLabel}>Gasto previsto:</Text>
          <TextInput
            style={styles.inputGasto}
            value={gastoPrevisto}
            onChangeText={handleGastoChange}
            keyboardType="numeric"
            placeholderTextColor="#FFFF"
          />
        </View>

        <TouchableOpacity
          style={styles.botaoAdicionar}
          onPress={handleAdicionar}
        >
          <Text style={styles.textoBotao}>+ Adicionar</Text>
        </TouchableOpacity>
      </View>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#00050D",
    padding: 20,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
    marginRight: 125,
    marginTop: 50,
  },
  logo: {
    width: 98,
    height: 83,
  },
  voltarIcone: {
    width: 30,
    height: 30,
  },
  label: {
    fontSize: 20,
    color: "#999",
    marginTop: 40,
    marginBottom: 10,
  },
  input: {
    color: "#999",
    fontSize: 18,
    width: "100%",
    backgroundColor: "transparent",
  },
  datas: {
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 20,
    width: "100%",
  },

  calendar: {
    backgroundColor: "transparent",
  },

  dataContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 10,
    width: "100%",
    justifyContent: "space-between",
  },
  linha: {
    borderBottomWidth: 1,
    borderBottomColor: "#FFF",
    width: "100%",
    marginTop: 5,
  },
  icone: {
    width: 28,
    height: 28,
    marginRight: 10,
  },
  textoDatas: {
    color: "#FFFFFF",
    fontSize: 15,
    flex: 1,
  },

  cidadeContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 20,
  },
  cidadeTexto: {
    color: "#FFFFFF",
    fontSize: 18,
    marginLeft: 10,
  },
  gastoContainer: {
    marginTop: 40,
  },
  gastoLabel: {
    color: "#FFFFFF",
    fontSize: 18,
  },
  inputGasto: {
    color: "#999",
    fontSize: 30,
    fontWeight: "bold",
    marginTop: 10,
    borderBottomColor: "#FFF",
  },
  botaoAdicionar: {
    backgroundColor: "#0E6EFF",
    borderRadius: 40,
    paddingVertical: 10,
    paddingHorizontal: 40,
    alignItems: "center",
    alignSelf: "center",
    marginTop: 180,
    marginLeft: 160,
  },
  textoBotao: {
    color: "#FFFFFF",
    fontSize: 20,
    fontWeight: "bold",
  },
});
