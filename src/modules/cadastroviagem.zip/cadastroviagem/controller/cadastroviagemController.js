import { useState, useEffect, useCallback } from "react";
import { useNavigation, useFocusEffect } from "@react-navigation/native"; 
import AsyncStorage from "@react-native-async-storage/async-storage";
import addNovaViagemUseCase from "../domain/addNovaViagemUseCase";

export default function useCadastroNovaViagemController() {
  const [cidade, setCidade] = useState("");
  const { salvarViagem } = CadastroViagemUseCase();

  const navigation = useNavigation(); 

  // Função para buscar a cidade armazenada no AsyncStorage
  const obterCidade = async () => {
    try {
      const cidadeArmazenada = await AsyncStorage.getItem("@nomeCidade");
      if (cidadeArmazenada) {
        setCidade(cidadeArmazenada);
        navigation.navigate("cadastroviagem"); 
      }
    } catch (error) {
      console.log("Erro ao obter a cidade armazenada:", error);
    }
  };

  useEffect(() => {
    obterCidade(); 
  }, []);

  const selecionarCidade = (cidadeSelecionada) => {
    setCidade(cidadeSelecionada);
    navigation.navigate("CadastroViagem"); 
  };

  const handleSalvarViagem = async ({ titulo, dataIda, dataVolta, gastoPrevisto }) => {
    const resultado = await salvarViagem({ titulo, dataIda, dataVolta, gastoPrevisto });
    
    if (resultado.success) {
      console.log(resultado.message);
      // Redireciona ou exibe uma mensagem de sucesso
    } else {
      console.error(resultado.message);
      // Exibe a mensagem de erro para o usuário
      alert(resultado.message); // Exemplo simples de exibição
    }
  };

  return { cidade, selecionarCidade, handleSalvarViagem };
}
